import Maintenance from '../../../components/Maintenance';

export default function MaintenancePage() {
  return <Maintenance />;
}
