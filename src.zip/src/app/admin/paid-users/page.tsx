'use client';

import { useState, useEffect, useMemo } from 'react';
import { Loader2, Download, Mail, Users, UserCheck, Calendar } from 'lucide-react';

interface Registration {
  id: string;
  name: string;
  email: string;
  contactNo: string;
  universityName: string;
  events: string[];
  registrationType: 'individual' | 'team-leader' | 'team-member';
  userType: string;
  hasEntered: boolean;
  emailSent: boolean;
  isvalidated: boolean;
  entryTime?: string;
  emailSentAt?: string;
  createdAt: string;
  qrCodeBase64: string;
  teamInfo?: Array<{
    teamId: string;
    teamName: string;
    eventName: string;
    teamLeaderName?: string;
    teamLeaderEmail?: string;
    totalMembers: number;
    paymentStatus: string;
  }>;
  purchases: Array<{
    orderId: string;
    totalAmount: number;
    paymentStatus: string;
    purchaseDate: string;
  }>;
  totalAmountPaid: number;
}

interface Stats {
  totalRegistrations: number;
  individualRegistrations: number;
  teamLeaders: number;
  teamMembers: number;
  validatedUsers: number;
  enteredUsers: number;
  emailsSent: number;
  qrCodesGenerated: number;
  totalRevenue: number;
  eventBreakdown: Record<string, number>;
  universityBreakdown: Record<string, number>;
  userTypeBreakdown: Record<string, number>;
}

export default function AllRegistrationsPage() {
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // Filter states
  const [searchTerm, setSearchTerm] = useState('');
  const [registrationTypeFilter, setRegistrationTypeFilter] = useState('all');
  const [eventFilter, setEventFilter] = useState('all');
  const [universityFilter, setUniversityFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [emailStatusFilter, setEmailStatusFilter] = useState('all');
  const [paymentStatusFilter, setPaymentStatusFilter] = useState('all');

  // Fetch all registrations
  useEffect(() => {
    fetchAllRegistrations();
  }, []);

  const fetchAllRegistrations = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/admin/all-registrations', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('adminToken')}`
        }
      });

      if (!response.ok) {
        throw new Error('Failed to fetch registrations');
      }

      const data = await response.json();
      setRegistrations(data.data);
      setStats(data.stats);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  // Get unique values for filter dropdowns
  const uniqueEvents = useMemo(() => {
    const events = new Set<string>();
    registrations.forEach(reg => {
      reg.events.forEach(event => events.add(event));
    });
    return Array.from(events).sort();
  }, [registrations]);

  const uniqueUniversities = useMemo(() => {
    const universities = new Set<string>();
    registrations.forEach(reg => {
      if (reg.universityName) universities.add(reg.universityName);
    });
    return Array.from(universities).sort();
  }, [registrations]);

  // Apply all filters
  const filteredRegistrations = useMemo(() => {
    return registrations.filter(registration => {
      // Search term filter
      if (searchTerm) {
        const searchLower = searchTerm.toLowerCase();
        const matchesSearch = 
          registration.name.toLowerCase().includes(searchLower) ||
          registration.email.toLowerCase().includes(searchLower) ||
          registration.contactNo.includes(searchTerm) ||
          registration.universityName.toLowerCase().includes(searchLower) ||
          registration.events.some(event => event.toLowerCase().includes(searchLower));
        
        if (!matchesSearch) return false;
      }

      // Registration type filter
      if (registrationTypeFilter !== 'all' && registration.registrationType !== registrationTypeFilter) {
        return false;
      }

      // Event filter
      if (eventFilter !== 'all' && !registration.events.includes(eventFilter)) {
        return false;
      }

      // University filter
      if (universityFilter !== 'all' && registration.universityName !== universityFilter) {
        return false;
      }

      // Status filter
      if (statusFilter !== 'all') {
        if (statusFilter === 'entered' && !registration.hasEntered) return false;
        if (statusFilter === 'not-entered' && registration.hasEntered) return false;
        if (statusFilter === 'validated' && !registration.isvalidated) return false;
        if (statusFilter === 'not-validated' && registration.isvalidated) return false;
      }

      // Email status filter
      if (emailStatusFilter !== 'all') {
        if (emailStatusFilter === 'sent' && !registration.emailSent) return false;
        if (emailStatusFilter === 'not-sent' && registration.emailSent) return false;
      }

      // Payment status filter
      if (paymentStatusFilter !== 'all') {
        const hasCompletedPayment = registration.purchases.some(p => p.paymentStatus === 'completed');
        if (paymentStatusFilter === 'completed' && !hasCompletedPayment) return false;
        if (paymentStatusFilter === 'pending' && hasCompletedPayment) return false;
      }

      return true;
    });
  }, [registrations, searchTerm, registrationTypeFilter, eventFilter, universityFilter, statusFilter, emailStatusFilter, paymentStatusFilter]);

  // Export functionality
  const exportToCSV = () => {
    const headers = [
      'Name', 'Email', 'Contact', 'University', 'Events', 'Type', 
      'Has Entered', 'Entry Time', 'Email Sent', 'Validated', 
      'Team Info', 'Total Paid', 'Created At'
    ];

    const rows = filteredRegistrations.map(reg => [
      reg.name,
      reg.email,
      reg.contactNo,
      reg.universityName,
      reg.events.join('; '),
      reg.registrationType,
      reg.hasEntered ? 'Yes' : 'No',
      reg.entryTime ? new Date(reg.entryTime).toLocaleString() : '',
      reg.emailSent ? 'Yes' : 'No',
      reg.isvalidated ? 'Yes' : 'No',
      reg.teamInfo?.map(t => `${t.teamName} (${t.eventName})`).join('; ') || '',
      `₹${reg.totalAmountPaid}`,
      new Date(reg.createdAt).toLocaleString()
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => 
        row.map(field => 
          typeof field === 'string' && field.includes(',') 
            ? `"${field.replace(/"/g, '""')}"` 
            : field
        ).join(',')
      )
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `sabrang_registrations_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Reset all filters
  const resetFilters = () => {
    setSearchTerm('');
    setRegistrationTypeFilter('all');
    setEventFilter('all');
    setUniversityFilter('all');
    setStatusFilter('all');
    setEmailStatusFilter('all');
    setPaymentStatusFilter('all');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
        <span className="ml-2">Loading all registrations...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-red-600 mb-2">Error</h2>
          <p className="text-gray-600">{error}</p>
          <button 
            onClick={fetchAllRegistrations} 
            className="mt-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">All Registrations</h1>
          <p className="text-gray-600 mt-1">
            Manage all registrations with advanced filtering
          </p>
        </div>
        <div className="flex gap-2">
          <button 
            onClick={exportToCSV} 
            className="px-4 py-2 border border-gray-300 rounded hover:bg-gray-50 flex items-center"
          >
            <Download className="w-4 h-4 mr-2" />
            Export CSV
          </button>
          <button 
            onClick={fetchAllRegistrations} 
            className="px-4 py-2 border border-gray-300 rounded hover:bg-gray-50"
          >
            Refresh Data
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-white border rounded-lg shadow">
            <div className="p-4 pb-2">
              <div className="text-sm font-medium flex items-center">
                <Users className="w-4 h-4 mr-2" />
                Total Registrations
              </div>
            </div>
            <div className="p-4">
              <div className="text-2xl font-bold">{stats.totalRegistrations}</div>
              <div className="text-xs text-gray-600">
                Individual: {stats.individualRegistrations} | 
                Leaders: {stats.teamLeaders} | 
                Members: {stats.teamMembers}
              </div>
            </div>
          </div>

          <div className="bg-white border rounded-lg shadow">
            <div className="p-4 pb-2">
              <div className="text-sm font-medium flex items-center">
                <UserCheck className="w-4 h-4 mr-2" />
                Entry Status
              </div>
            </div>
            <div className="p-4">
              <div className="text-2xl font-bold">{stats.enteredUsers}</div>
              <div className="text-xs text-gray-600">
                Validated: {stats.validatedUsers}
              </div>
            </div>
          </div>

          <div className="bg-white border rounded-lg shadow">
            <div className="p-4 pb-2">
              <div className="text-sm font-medium flex items-center">
                <Mail className="w-4 h-4 mr-2" />
                Email Status
              </div>
            </div>
            <div className="p-4">
              <div className="text-2xl font-bold">{stats.emailsSent}</div>
              <div className="text-xs text-gray-600">
                QR Generated: {stats.qrCodesGenerated}
              </div>
            </div>
          </div>

          <div className="bg-white border rounded-lg shadow">
            <div className="p-4 pb-2">
              <div className="text-sm font-medium flex items-center">
                <Calendar className="w-4 h-4 mr-2" />
                Revenue
              </div>
            </div>
            <div className="p-4">
              <div className="text-2xl font-bold">₹{stats.totalRevenue.toLocaleString()}</div>
              <div className="text-xs text-gray-600">
                Total collected
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="bg-white border rounded-lg shadow">
        <div className="p-4">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-medium">Filters</h3>
            <button 
              onClick={resetFilters} 
              className="px-3 py-1 text-sm text-gray-600 hover:text-gray-800"
            >
              Reset All
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
            <div>
              <label className="text-sm font-medium mb-1 block">Search</label>
              <input
                type="text"
                placeholder="Search by name, email, contact..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="text-sm font-medium mb-1 block">Registration Type</label>
              <select 
                value={registrationTypeFilter} 
                onChange={(e) => setRegistrationTypeFilter(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">All Types</option>
                <option value="individual">Individual</option>
                <option value="team-leader">Team Leader</option>
                <option value="team-member">Team Member</option>
              </select>
            </div>

            <div>
              <label className="text-sm font-medium mb-1 block">Event</label>
              <select 
                value={eventFilter} 
                onChange={(e) => setEventFilter(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">All Events</option>
                {uniqueEvents.map(event => (
                  <option key={event} value={event}>{event}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-sm font-medium mb-1 block">University</label>
              <select 
                value={universityFilter} 
                onChange={(e) => setUniversityFilter(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">All Universities</option>
                {uniqueUniversities.map(university => (
                  <option key={university} value={university}>{university}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-sm font-medium mb-1 block">Entry Status</label>
              <select 
                value={statusFilter} 
                onChange={(e) => setStatusFilter(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">All Status</option>
                <option value="entered">Has Entered</option>
                <option value="not-entered">Not Entered</option>
                <option value="validated">Validated</option>
                <option value="not-validated">Not Validated</option>
              </select>
            </div>

            <div>
              <label className="text-sm font-medium mb-1 block">Email Status</label>
              <select 
                value={emailStatusFilter} 
                onChange={(e) => setEmailStatusFilter(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">All Email Status</option>
                <option value="sent">Email Sent</option>
                <option value="not-sent">Email Not Sent</option>
              </select>
            </div>

            <div>
              <label className="text-sm font-medium mb-1 block">Payment Status</label>
              <select 
                value={paymentStatusFilter} 
                onChange={(e) => setPaymentStatusFilter(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">All Payment Status</option>
                <option value="completed">Completed</option>
                <option value="pending">Pending</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Results Summary */}
      <div className="flex items-center justify-between">
        <div className="text-sm text-gray-600">
          Showing {filteredRegistrations.length} of {registrations.length} registrations
        </div>
      </div>

      {/* Registrations Table */}
      <div className="bg-white border rounded-lg shadow">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-medium">Name</th>
                <th className="px-4 py-3 text-left text-sm font-medium">Email</th>
                <th className="px-4 py-3 text-left text-sm font-medium">Type</th>
                <th className="px-4 py-3 text-left text-sm font-medium">Events</th>
                <th className="px-4 py-3 text-left text-sm font-medium">Status</th>
                <th className="px-4 py-3 text-left text-sm font-medium">Team Info</th>
                <th className="px-4 py-3 text-left text-sm font-medium">University</th>
                <th className="px-4 py-3 text-left text-sm font-medium">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {filteredRegistrations.map((registration) => (
                <tr key={registration.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3">
                    <div>
                      <div className="font-medium">{registration.name}</div>
                      <div className="text-sm text-gray-500">{registration.contactNo}</div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-sm">{registration.email}</td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${
                      registration.registrationType === 'individual' 
                        ? 'bg-blue-100 text-blue-800' 
                        : registration.registrationType === 'team-leader' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-gray-100 text-gray-800'
                    }`}>
                      {registration.registrationType}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex flex-wrap gap-1">
                      {registration.events.slice(0, 2).map((event, idx) => (
                        <span key={idx} className="inline-flex px-2 py-1 text-xs bg-gray-100 text-gray-800 rounded-full">
                          {event}
                        </span>
                      ))}
                      {registration.events.length > 2 && (
                        <span className="inline-flex px-2 py-1 text-xs bg-gray-100 text-gray-800 rounded-full">
                          +{registration.events.length - 2}
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex flex-col gap-1">
                      <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full w-fit ${
                        registration.hasEntered ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {registration.hasEntered ? 'Entered' : 'Not Entered'}
                      </span>
                      <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full w-fit ${
                        registration.emailSent ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                      }`}>
                        {registration.emailSent ? 'Email Sent' : 'No Email'}
                      </span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    {registration.teamInfo && registration.teamInfo.length > 0 ? (
                      <div className="text-sm">
                        {registration.teamInfo.map((team, idx) => (
                          <div key={idx} className="mb-1">
                            <div className="font-medium">{team.teamName}</div>
                            <div className="text-gray-500 text-xs">
                              {team.eventName} ({team.totalMembers} members)
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <span className="text-gray-400 text-sm">Individual</span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-sm">{registration.universityName}</td>
                  <td className="px-4 py-3">
                    <div className="flex gap-2">
                      <button className="px-2 py-1 text-xs border border-gray-300 rounded hover:bg-gray-50">
                        View
                      </button>
                      {!registration.emailSent && (
                        <button className="px-2 py-1 text-xs border border-gray-300 rounded hover:bg-gray-50 flex items-center">
                          <Mail className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {filteredRegistrations.length === 0 && (
        <div className="text-center py-8">
          <p className="text-gray-500">No registrations found matching your filters.</p>
        </div>
      )}
    </div>
  );
}
